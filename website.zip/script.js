document.addEventListener('DOMContentLoaded', () => {
    // Smooth Scrolling for Navigation Links
    document.querySelectorAll('.nav-link, .hero-actions .btn').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();

            const targetId = this.getAttribute('href');
            if (targetId.startsWith('#')) {
                const targetElement = document.querySelector(targetId);
                if (targetElement) {
                    // Close mobile menu if open
                    const mobileNav = document.querySelector('.nav-menu');
                    const menuToggle = document.querySelector('.menu-toggle');
                    if (mobileNav.classList.contains('active')) {
                        mobileNav.classList.remove('active');
                        menuToggle.classList.remove('active');
                    }

                    window.scrollTo({
                        top: targetElement.offsetTop - (document.querySelector('.header').offsetHeight), // Adjust for fixed header height
                        behavior: 'smooth'
                    });
                }
            }
        });
    });

    // Mobile Navigation Toggle
    const menuToggle = document.querySelector('.menu-toggle');
    const navMenu = document.querySelector('.nav-menu');

    menuToggle.addEventListener('click', () => {
        navMenu.classList.toggle('active');
        menuToggle.classList.toggle('active');
        document.body.classList.toggle('no-scroll'); // Optional: disable body scroll when menu is open
    });

    // Close mobile menu when clicking outside (optional, but good UX)
    document.addEventListener('click', (e) => {
        if (!navMenu.contains(e.target) && !menuToggle.contains(e.target) && navMenu.classList.contains('active')) {
            navMenu.classList.remove('active');
            menuToggle.classList.remove('active');
            document.body.classList.remove('no-scroll');
        }
    });

    // Simple Fade-in Animation for Sections
    const fadeElements = document.querySelectorAll('.fade-in');

    const observerOptions = {
        root: null, // viewport
        rootMargin: '0px',
        threshold: 0.1 // 10% of element visible
    };

    const observer = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('appear');
                observer.unobserve(entry.target); // Stop observing once it has appeared
            }
        });
    }, observerOptions);

    fadeElements.forEach(el => {
        observer.observe(el);
    });

    // Add initial fade-in for hero content (if needed, otherwise CSS handles it)
    // For hero content, it's often better to just have it appear directly or with a quick CSS animation.
    // However, if hero content should also fade-in, it needs a parent `fade-in` class
    // and would be observed. For this portfolio, the hero is direct, and other sections use `fade-in`.
});